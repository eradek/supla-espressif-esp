
#ifndef SONOFF_H_
#define SONOFF_H_

#define ESP8266_SUPLA_PROTO_VERSION 7
#define CFGBTN_TYPE_SELECTION

void supla_esp_board_send_channel_values_with_delay(void *srpc);

#endif
